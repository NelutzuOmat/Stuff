﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.NetworkInformation;
using System.IO;

namespace TCPClient_v1
{
    class Program
    {

        static void PingTest(string server)
        {

            Ping pingSender = new Ping();
            PingOptions options = new PingOptions();

            // Use the default Ttl value which is 128,
            // but change the fragmentation behavior.
            options.DontFragment = true;

            // Create a buffer of 32 bytes of data to be transmitted.
            string data = "Sample data sent";
            byte[] buffer = Encoding.ASCII.GetBytes(data);
            int timeout = 120;
            PingReply reply = pingSender.Send(server, timeout, buffer, options);
            if (reply.Status == IPStatus.Success)
            {
                Console.WriteLine("Address: {0}", reply.Address.ToString());
                Console.WriteLine("RoundTrip time: {0}", reply.RoundtripTime);
                Console.WriteLine("Time to live: {0}", reply.Options.Ttl);
                Console.WriteLine("Don't fragment: {0}", reply.Options.DontFragment);
                Console.WriteLine("Buffer size: {0}", reply.Buffer.Length);
                Console.WriteLine();
            }
            else
            {
                Console.WriteLine("Ultra Giga Fail");
                Console.WriteLine();
            }

        }

        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("The app is open");
                Console.SetIn(new StreamReader(Console.OpenStandardInput(4000)));
                Console.WriteLine("New input length");
                int option = 1;
                int setupOption = 1;
                string input;

                string server = "10.220.12.143";
                int port = 7;
                while (setupOption != 0)
                {
                    Console.WriteLine("===================================================");
                    Console.WriteLine("Setup server address and port:");
                    Console.WriteLine("1. Default      (PC <-> FPGA) : 192 . 168 .   1 .  10  :7");
                    Console.WriteLine("2. Default (NETWORK <-> FPGA) :  10 . 220 .  12 . 143  :7");
                    Console.WriteLine("3. Custom Setup");
                    Console.WriteLine();
                    Console.WriteLine("0. Exit");
                    Console.WriteLine();
                    Console.WriteLine("Optiune aleasa:");
                    input = Console.ReadLine();
                    int.TryParse(input, out setupOption);

                    switch (setupOption)
                    {
                        case 1:
                            Console.WriteLine("------ Setup defaulted to: 192.168.1.10:7"); server = "192.168.1.10"; port = 7; break;
                        case 2:
                            Console.WriteLine("------ Setup defaulted to: 10.220.12.143:7"); server = "10.220.12.143"; port = 7; break;
                        case 3:
                            Console.WriteLine("---------------------------------------------------");
                            Console.WriteLine("Server Address:");
                            input = Console.ReadLine();
                            server = input;
                            Console.WriteLine("Server Port:");
                            input = Console.ReadLine();
                            int.TryParse(input, out port);
                            break;
                    }
                    Console.WriteLine("===================================================");

                    TcpConnector tcpconnector = new TcpConnector(server, port);
                    while (option != 0)
                    {
                        Console.WriteLine("---------------------------------------------------");
                        Console.WriteLine("Menu:");
                        Console.WriteLine("1. PingTest");
                        Console.WriteLine("2. TCP Test");
                        Console.WriteLine("3. TCP Test with custom message");
                        Console.WriteLine();
                        Console.WriteLine("0. Exit");
                        Console.WriteLine();
                        Console.WriteLine("Optiune aleasa:");

                        input = Console.ReadLine();
                        int.TryParse(input, out option);

                        switch (option)
                        {
                            case 1: PingTest(server); break;
                            case 2: tcpconnector.Connect(); break;
                            case 3: Console.WriteLine("Mesajul pentru transmisie este: "); string message = Console.ReadLine(); message = message + message + message + message + message + message + message; tcpconnector.Connect(message); break;
                        }
                    }
                    option = 1;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Exceptie Unhandled: {0}", e.StackTrace);
            }
        }
    }
}
