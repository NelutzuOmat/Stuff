/******************************************************************************
*
* Copyright (C) 2009 - 2014 Xilinx, Inc.  All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running on a Xilinx device, or
* (b) that interact with a Xilinx device through a bus or interconnect.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* XILINX  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the Xilinx shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from Xilinx.
*
******************************************************************************/

/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "Sensor.h"
#include "microblaze_sleep.h"
#include "xil_io.h"
#include "xparameters.h"
// general writing
void setGeneral(u32 command, u32 stuffToWrite);
// general reading
u32 getGeneral(u32 command);
// Read temperature 0000
u32 getTemperature();
// Read status 0010
u32 getStatus();
// Read config 0100
u32 getConfig();
//Write config 0101
void setConfig(u32 value);
// Read TH 0110
u32  getTempHigh();
//Write TH 0111
void setTempHigh(u32 value);
// Read TL 1000
u32 getTempLow();
//Write TL 1001
void setTempLow(u32 value);
// Read TC 1010
u32 getTempCrit();
//Write TC 1011
void setTempCrit(u32 value);
// Read TH 1100
u32 getTempHyst();
//Write TH 1101
void setTempHyst(u32 value);
// Read ID 1110
u32 getID();
//Write RESET 1111
void softReset();
//List commands
void listCommands();
u32 getFractionary(u32 val);

int main()
{
    init_platform();

    xil_printf("Hello World %u\n\r",0x1f);

    	int chooser = 0;
        u32 val = 0x00000000;
        u32 valWrite = 0x00000000;
        listCommands();
        while(1){
        	print("Choose your command: \t");
        	scanf("%d",&chooser);

        	switch(chooser){
        	case 0:  val = getTemperature();
        			 u32 frac = getFractionary(val);
        			 print("Read value is: ");
        			 xil_printf("(%x)uhex",val);
        			 val = val >> 3;
        			 xil_printf(" | (%x)hex",val);
        			 val = val >> 4;
        			 xil_printf(" | (%d.%04x)dec\n\r",val,frac);
        					break;
        	case 1:  listCommands();
        					break;
        	case 2:  val = getStatus();
        			 xil_printf("Read value is: %x\n\r",val);
        					break;
        	case 4:  val = getConfig();
        			 xil_printf("Read value is: %x\n\r",val);
							break;
        	case 5:  setConfig(valWrite);
        					break;
        	case 6:  val = getTempHigh();
        			 xil_printf("Read value is: %x\n\r",val);
        					break;
        	case 7:  setTempHigh(valWrite);
        					break;
        	case 8:  val = getTempLow();
        			 xil_printf("Read value is: %x\n\r",val);
        					break;
        	case 9:  setTempLow(valWrite);
        					break;
        	case 10: val = getTempCrit();
        			 xil_printf("Read value is: %x\n\r",val);
        					break;
        	case 11: setTempCrit(valWrite);
        					break;
        	case 12: val = getTempHyst();
        			 xil_printf("Read value is: %x\n\r",val);
        					break;
        	case 13: setTempHyst(val);
        					break;
        	case 14: val = getID();
        			 xil_printf("Read value is: %x\n\r",val);
        					break;
        	case 15: softReset();
        					break;
        	default:
        		print("What shall we write in there?\n\r\t");
        		scanf("%x",&valWrite);
        	}
        }


    cleanup_platform();
    return 0;
}

// general writing
void setGeneral(u32 command, u32 stuffToWrite){
    SENSOR_mWriteReg(XPAR_SENSOR_0_S00_AXI_BASEADDR,SENSOR_S00_AXI_SLV_REG1_OFFSET,stuffToWrite);
    SENSOR_mWriteReg(XPAR_SENSOR_0_S00_AXI_BASEADDR,SENSOR_S00_AXI_SLV_REG0_OFFSET,command);
    u32 reg3 = SENSOR_mReadReg(XPAR_SENSOR_0_S00_AXI_BASEADDR,SENSOR_S00_AXI_SLV_REG3_OFFSET);
	u32 mask = 0x00000001;
	while((reg3 & mask) != 0x00000001){
		MB_Sleep(100);
		reg3 = SENSOR_mReadReg(XPAR_SENSOR_0_S00_AXI_BASEADDR,SENSOR_S00_AXI_SLV_REG3_OFFSET);
	}
    SENSOR_mWriteReg(XPAR_SENSOR_0_S00_AXI_BASEADDR,SENSOR_S00_AXI_SLV_REG0_OFFSET,0x00000000);
}
// general reading
u32 getGeneral(u32 command){
    SENSOR_mWriteReg(XPAR_SENSOR_0_S00_AXI_BASEADDR,SENSOR_S00_AXI_SLV_REG0_OFFSET,command);
    u32 mask = 0x00000001;
    u32 reg3 = SENSOR_mReadReg(XPAR_SENSOR_0_S00_AXI_BASEADDR,SENSOR_S00_AXI_SLV_REG3_OFFSET);
    while((reg3 & mask) != 0x00000001){
    	MB_Sleep(100);
    	reg3 = SENSOR_mReadReg(XPAR_SENSOR_0_S00_AXI_BASEADDR,SENSOR_S00_AXI_SLV_REG3_OFFSET);
    }
    u32 reg2 = SENSOR_mReadReg(XPAR_SENSOR_0_S00_AXI_BASEADDR,SENSOR_S00_AXI_SLV_REG2_OFFSET);
    SENSOR_mWriteReg(XPAR_SENSOR_0_S00_AXI_BASEADDR,SENSOR_S00_AXI_SLV_REG0_OFFSET,0x00000000);
    return reg2;
}
// Read temperature 0000 - 0
u32 getTemperature(){
	u32 val = getGeneral(0x00000010);
	//val = val >> 3;
	return val;
}
// Read status 0010 - 2
u32 getStatus(){
	return getGeneral(0x00000012);
}
// Read config 0100 - 4
u32 getConfig(){
	return getGeneral(0x00000014);
}
//Write config 0101 - 5
void setConfig(u32 value){
	u32 value_shl = value << 8;
	setGeneral(0x00000015,value_shl);
}
// Read TH 0110 - 6
u32  getTempHigh(){
	return getGeneral(0x00000016);
}
//Write TH 0111 - 7
void setTempHigh(u32 value){
	setGeneral(0x00000017,value);
}
// Read TL 1000 - 8
u32 getTempLow(){
	return getGeneral(0x00000018);
}
//Write TL 1001 - 9
void setTempLow(u32 value){
	setGeneral(0x00000019,value);
}
// Read TC 1010 - A
u32 getTempCrit(){
	return getGeneral(0x0000001A);
}
//Write TC 1011 - B
void setTempCrit(u32 value){
	setGeneral(0x0000001B,value);
}
// Read TH 1100 - C
u32 getTempHyst(){
	return getGeneral(0x0000001C);
}
// Write TH 1101 - D
void setTempHyst(u32 value){
	u32 value_shl = value << 8;
	setGeneral(0x0000001D,value_shl);
}
// Read ID 1110 - E
u32 getID(){
	return getGeneral(0x0000001E);
}
//Write RESET 1111 - F
void softReset(){
	setGeneral(0x0000001F,0);
}


//List commands
void listCommands(){
	print("The commands:\n\r");
	print(" 0. Read Temperature\n\r");
	print(" 1. Redisplay this list\n\r");
	print(" 2. Read Status\n\r");
	print(" 3. Change the value to write for write commands\n\r");
	print(" 4. Read Configuration\n\r");
	print(" 5. Write Configuration\n\r");
	print(" 6. Read Temperature High\n\r");
	print(" 7. Write Temperature High\n\r");
	print(" 8. Read Temperature Low\n\r");
	print(" 9. Write Temperature Low\n\r");
	print("10. Read Temperature Critical\n\r");
	print("11. Write Temperature Critical\n\r");
	print("12. Read Temperature Hysteresis\n\r");
	print("13. Write Temperature Hysteresis\n\r");
	print("14. Read Device ID\n\r");
	print("15. Reset the Sensor\n\r");
	print("Others. Change what to write value\n\r");
}

u32 getFractionary(u32 val){
	u32 frac = val & 0x00000000F;
	switch (frac){
	case 0x1: return 0x0625;
	case 0x2: return 0x1250;
	case 0x3: return 0x1875;
	case 0x4: return 0x2500;
	case 0x5: return 0x3125;
	case 0x6: return 0x3750;
	case 0x7: return 0x4375;
	case 0x8: return 0x5000;
	case 0x9: return 0x5625;
	case 0xa: return 0x6250;
	case 0xb: return 0x6875;
	case 0xc: return 0x7500;
	case 0xd: return 0x8125;
	case 0xe: return 0x8750;
	case 0xf: return 0x9375;
	case 0x0: return 0x0000;
	default: return 0x0000;
	}
}

